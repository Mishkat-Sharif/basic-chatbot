
const chatBox = document.getElementById("chat-box");

function addMessage(text, sender){
  const div = document.createElement("div");
  div.classList.add("message", sender);
  div.innerText = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage(){
  const input = document.getElementById("user-input");
  const text = input.value.trim();

  if(!text) return;

  addMessage(text, "user");
  input.value = "";

  try{
    // Example AI response
    const botReply = "This is a demo AI response for: " + text;

    setTimeout(() => {
      addMessage(botReply, "bot");
    }, 500);

  }catch(error){
    addMessage("Error connecting AI.", "bot");
  }
}

function newChat(){
  chatBox.innerHTML = `
    <div class="message bot">
      New chat started!
    </div>
  `;
}
