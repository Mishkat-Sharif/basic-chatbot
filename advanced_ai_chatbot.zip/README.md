
# Advanced AI Chatbot

Features:
- Modern responsive UI
- AI chat interface
- Login & Registration UI
- Chat history support
- Image generator section
- Easy API integration

## Setup

1. Install Node.js
2. Open terminal
3. Run:

```bash
npm install
npm start
```

## API Integration

Replace `YOUR_API_KEY` inside `script.js`
